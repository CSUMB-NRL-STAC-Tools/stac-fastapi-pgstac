import pytest
from datetime import datetime, timezone
import pystac

from nhc_recon_parser import parser

@pytest.fixture
def sample_temp_drop_message():
    # Minimal valid TEMP DROP message for testing
    return (
        "123456\n"
        "TTAA AF303 010600\n"
        "XXAA 01060 99123 51234 12345\n"
        "10000 01501 27015 85000 01201 28020 70000 00501 29025\n"
        "88999\n"
        "77999\n"
        "31313 12345 01234\n"
        "61616 AF303 01WSW IOP1 OB 05\n"
        "62626 MBL WND 0600Z 180/20 KNOTS AT 1500 FEET\n"
    )

def test_decode_pressure_height_pressure():
    # Test pressure decoding
    pressure, height = parser.decode_pressure_height("10000")
    assert pressure == 1000.0
    assert height is None

def test_decode_pressure_height_height():
    # Test height decoding
    pressure, height = parser.decode_pressure_height("60000")
    assert pressure is None
    assert height == 600000.0

def test_decode_pressure_height_invalid():
    with pytest.raises(ValueError):
        parser.decode_pressure_height("1234")  # Too short

def test_decode_temp_dewpoint_positive():
    temp, dew = parser.decode_temp_dewpoint("01501")
    assert temp == 1.5
    assert dew == 0.1

def test_decode_temp_dewpoint_negative():
    temp, dew = parser.decode_temp_dewpoint("00511")
    assert temp == -0.5
    assert dew == 0.1

def test_decode_temp_dewpoint_invalid():
    with pytest.raises(ValueError):
        parser.decode_temp_dewpoint("01521")  # Invalid Ta

def test_decode_wind_normal():
    wind_dir, wind_speed = parser.decode_wind("27015")
    assert wind_dir == 270
    assert wind_speed == 15

def test_decode_wind_calm():
    wind_dir, wind_speed = parser.decode_wind("00000")
    assert wind_dir == 0
    assert wind_speed == 0

def test_decode_wind_invalid():
    with pytest.raises(ValueError):
        parser.decode_wind("1234")  # Too short

def test_parse_temp_drop(sample_temp_drop_message):
    uri = "file:///tmp/202406010600.txt"
    parsed = parser.parse_temp_drop(sample_temp_drop_message, uri)
    assert isinstance(parsed, dict)
    assert parsed["uri"] == uri
    assert "header" in parsed
    assert "part_a_mandatory_levels" in parsed
    assert isinstance(parsed["part_a_mandatory_levels"], list)
    assert "remarks" in parsed

def test_convert_dropsonde_to_stac_item(sample_temp_drop_message):
    uri = "file:///tmp/202406010600.txt"
    parsed = parser.parse_temp_drop(sample_temp_drop_message, uri)
    item = parser.convert_dropsonde_to_stac_item(parsed)
    assert isinstance(item, pystac.Item)
    assert item.geometry is not None
    assert "datetime" in item.properties
    assert "dropsonde:icao_originator" in item.properties
    assert "raw_dropsonde_message" in item.assets

def test_parse_temp_drop_invalid_datetime():
    # Should fall back to current UTC time if datetime can't be parsed
    message = "123456\nTTAA AF303 010600\nXXAA 01060 99123 51234 12345\n"
    uri = "file:///tmp/invalidfilename.txt"
    parsed = parser.parse_temp_drop(message, uri)
    assert isinstance(parsed["message_date"], datetime)
    assert parsed["message_date"].tzinfo == timezone.utc